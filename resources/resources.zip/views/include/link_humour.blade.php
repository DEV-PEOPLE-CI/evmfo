<a href="/sport_et_culture" id="hero_pc">
    <section class="hero"   style="background-image: url('{{asset('images/pc.jpg')}}');"></section>
</a>

<a href="/sport_et_culture" id="hero_mobile">
    <section class="hero"  style="background-image: url('{{asset('images/mobile.jpg')}}');"></section>

</a>
