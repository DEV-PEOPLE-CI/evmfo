<footer>
    <div class="contact">
            <h3>CONTACTS UTILES</h3>
            <div style="text-align: center">
              <span>
                  <h3>Police: 170 - 111</h3>
              </span>
                <span>
                  <h3>SOS Medecin :185</h3>
              </span>
                <span>
                  <h3>Reanimation:186</h3>
              </span>
                <span>
                  <h3>Sapeur Pompier: 180</h3>
              </span>
                <span>
                  <h3>CIE: 179</h3>
              </span>
                <span>
                  <h3>SODECI: 175</h3>
              </span>
            </div>
    </div>
    <div class="info">
            <h3 class="titre_eveil_h3">EVEIL MEDIA</h3>
            <div style="text-align: center" class="elmt_num">
                <ul class="number_eveil">
                    <h4 class="titre_eveil">Siege</h4>
                    <li class="li_txt"> Abidjan, Yopougon 16eme<br> Arrondissement</li>
                </ul>
                <ul class="number_eveil">
                    <h4 class="titre_eveil">E-mail</h4>
                    <li class="li_txt"><a href="mailto:eveilmedia85@gmail.com" style="color:white;">mediaeveil85@gmail.com</a></li>
                </ul>
                <ul class="number_eveil">
                    <h4 class="txt_telephone">Télephone</h4>
                    <li class="li_txt"><a href="tel:+2250102785073">(+225)0102785073</a></li>
                    <li class="li_txt"><a href="tel:+2252523006273">(+225)2523006273</a></li>
                    <li class="li_txt"><a href="tel:+2250799851192">(+225)0799851192</a></li>
                </ul>
            </div>
    </div>
    <div class="ncpr">
      <span>
          <!--<p>©2022 Dev'People | Eveil Media </p>-->
      </span>
    </div>
</footer>
