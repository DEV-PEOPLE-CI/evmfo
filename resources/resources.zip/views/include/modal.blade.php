
<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" onclick="close_modal()" style="background: none-webkit-backdrop-filter: blur(15px); /* assure la compatibilité avec safari */
    backdrop-filter: blur(15px);background-color: rgba(182, 182, 182, 0.2);">
    <div class="modal-dialog"style="background: none;">
        <div class="modal-content "style="background: none">
            <div class="modal-header" style="border: none">

                <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="close_modal()">
                    <span aria-hidden="true" style="color: white">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="video_show"style="background: black">
                ...
            </div>

        </div>
    </div>
</div>



