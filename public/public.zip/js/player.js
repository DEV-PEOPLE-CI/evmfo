/*var player1 = document.getElementById("player1");
var player2 = document.getElementById("player2");
var player3 = document.getElementById("player3");
var btn1 = document.getElementById("btn1");
var bt2 = document.getElementById("btn2");
var btn3 = document.getElementById("btn3");
*//*
function playpause1(){
    if (player1.paused) {
      player1.play();
      player2.pause();
      player3.pause();

      btn1.src = "images/paused.png";
      btn1.className = "mr-3 rounded-circle video_paused";
      btn2.src = "images/play.png";
      btn3.src = "images/play.png";
    } else {
        player1.pause();
        btn1.src = "images/play.png";
        btn1.className = "mr-3 rounded-circle video_play";
    }
}
function playpause2(){
  if (player2.paused) {
    player2.play();
    player1.pause();
    player3.pause();

    btn2.src = "images/paused.png";
    btn2.className = "mr-3 rounded-circle video_paused";
    btn1.src = "images/play.png";
    btn3.src = "images/play.png";
  } else {
      player2.pause();
      btn2.src = "images/play.png";
      btn2.className = "mr-3 rounded-circle video_play";
  }
}
function playpause3(){
  if (player3.paused) {
    player3.play();
    player2.pause();
    player1.pause();

    btn3.src = "images/paused.png";
    btn3.className = "mr-3 rounded-circle video_paused";
    btn2.src = "images/play.png";
    btn1.src = "images/play.png";
  } else {
      player3.pause();
      btn3.src = "images/play.png";
      btn3.className = "mr-3 rounded-circle video_play";
  }
}
*/
